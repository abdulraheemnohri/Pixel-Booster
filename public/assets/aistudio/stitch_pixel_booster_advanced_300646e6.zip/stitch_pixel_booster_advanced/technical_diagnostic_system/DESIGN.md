---
name: Technical Diagnostic System
colors:
  surface: '#091326'
  surface-dim: '#091326'
  surface-bright: '#30394e'
  surface-container-lowest: '#050e21'
  surface-container-low: '#121b2f'
  surface-container: '#161f33'
  surface-container-high: '#212a3e'
  surface-container-highest: '#2c344a'
  on-surface: '#d9e2fe'
  on-surface-variant: '#c2c7d0'
  inverse-surface: '#d9e2fe'
  inverse-on-surface: '#273045'
  outline: '#8c919a'
  outline-variant: '#42474f'
  surface-tint: '#a1c9ff'
  primary: '#cee1ff'
  on-primary: '#00325a'
  primary-container: '#9cc7ff'
  on-primary-container: '#235384'
  inverse-primary: '#336192'
  secondary: '#83d7b4'
  on-secondary: '#003828'
  secondary-container: '#00694d'
  on-secondary-container: '#91e5c2'
  tertiary: '#ffdaa5'
  on-tertiary: '#432c00'
  tertiary-container: '#e9bd78'
  on-tertiary-container: '#6a4b10'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d2e4ff'
  primary-fixed-dim: '#a1c9ff'
  on-primary-fixed: '#001c37'
  on-primary-fixed-variant: '#154979'
  secondary-fixed: '#9ff4d0'
  secondary-fixed-dim: '#83d7b4'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#00513b'
  tertiary-fixed: '#ffdead'
  tertiary-fixed-dim: '#ecbf7a'
  on-tertiary-fixed: '#281900'
  on-tertiary-fixed-variant: '#5f4105'
  background: '#091326'
  on-background: '#d9e2fe'
  surface-variant: '#2c344a'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 44px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.03em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xxs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-xxl: 2rem
---

## Brand & Style

This design system expresses a high-precision, diagnostic utility rooted in Google’s Material 3 philosophy, adapted specifically for high-performance hardware and OS monitoring. The aesthetic balances system-level technical authority with fluid, ambient software refinement. It avoids the visual noise of classic "gamer/tuner" utilities, opting instead for a pristine, lab-grade telemetry environment.

The target audience encompasses Android power users, performance enthusiasts, and telemetry analysts who demand dense, legible data without sacrificing tactile modern aesthetics. The interface evokes clinical reliability, immediate responsiveness, and total system transparency. 

Key visual principles:
- **Calibrated Precision:** Diagnostic telemetry and status metrics take visual precedence; data points are presented with monospaced-like clarity and balanced padding.
- **Atmospheric Layering:** Soft midnight navy surfaces step back to create infinite depth, allowing glowing status mints, ambers, and soft blues to signal critical hardware thresholds without visual fatigue.
- **Material 3 Expressive Forms:** Generous organic radii, pill-shaped metric containers, and tactile state feedback ground the utility in modern Pixel-first ergonomics.

## Colors

The palette is tuned specifically for deep-contrast, dark-mode-first diagnostic clarity, eliminating glare while maximizing visual hierarchy during active benchmarking.

- **Canvas Root (`#0A1020`):** The foundational void beneath all container tiers.
- **Main Surface (`#151E32`):** Base structural layer for structural frames, docked rails, and underlying toolbars.
- **Elevated Card Surface (`#202C45`):** The primary container tone for modular telemetry modules, active diagnostic reports, and operational controls.
- **High-Elevation Accent Surface (`#2D3D5E`):** Reserved for nested components, inner gauge tracks, chips, and elevated interaction points.
- **System Accents:**
  - **Primary (`#9CC7FF`):** Soft electric blue representing default active states, system operations, and diagnostic focus.
  - **Positive / Nominal (`#8FE3C0`):** Soft mint indicating optimal thermals, stable clock rates, and healthy battery life.
  - **Warning / Degraded (`#FFD18A`):** Warm amber signaling throttling, capacity degradation, or background resource contention.
  - **Critical / Fault (`#FF8A8A`):** Vivid coral red reserved for critical thermals, battery faults, and aggressive task killing.
- **Typography Tokens:**
  - **Primary Text (`#F4F7FC`):** Pure telemetry readouts, dominant values, and titles.
  - **Secondary Text (`#ABB7CC`):** Unit descriptors (MHz, °C, mA), subtitles, and static labels.
  - **Outline / Low-Contrast Border (`#273756`):** Delicate 1px separator boundaries to demarcate card perimeters without sharp visual breaks.

## Typography

The type scale combines the technical rigor of `Space Grotesk` with the ergonomic legibility of `Plus Jakarta Sans`. 

- **Space Grotesk** governs all numbers, metrics, headlines, badge values, and navigation labels. Its geometric, slightly mechanical proportions reinforce the diagnostic instrument motif. Numbers render cleanly with proportional figures, and its letterforms maintain readability at high velocity and compact sizes.
- **Plus Jakarta Sans** is leveraged across standard prose, descriptive diagnostic notes, contextual logs, and long-form tooltips. It softens the interface, preventing visual fatigue during extended triage sessions.

Numeric labels and key performance indicators should always utilize uppercase tracking with `label-sm` or `label-md` to maintain telemetry legibility.

## Layout & Spacing

The layout is built upon a responsive 8pt geometric grid system adapted for handheld density and dashboard reflow.

- **Mobile (<600px):** 4-column layout with 16px margins and 16px gutters. Metric modules default to full-width or paired 2-column cards. The bottom navigation bar remains pinned to the viewport floor.
- **Tablet (600px - 1024px):** 8-column layout with 24px margins and 20px gutters. Gauge widgets and system health diagnostics sit side-by-side in double-wide cards.
- **Desktop / Foldable Expanded (>1024px):** 12-column layout with 32px outer canvas margins and 24px gutters. Bottom navigation collapses into a left-aligned vertical diagnostic navigation rail.

Vertical rhythm follows strict multiples of `0.25rem` (4px). Structural cards enforce internal padding of `space-lg` (20px) to comfortably nest technical metrics without crowd pressure.

## Elevation & Depth

Visual hierarchy is constructed through precise tonal surfaces, subdued ghost borders, and focused chromatic glows rather than traditional black drop shadows.

- **Level 0 (Canvas Base):** Background `#0A1020`, non-interactive canvas.
- **Level 1 (Sub-surface / Tracks):** Surface `#151E32`, used for background tracks of progress rings, unfilled gauge slots, and static segment dividers.
- **Level 2 (Standard Telemetry Card):** Elevated surface `#202C45`, bounded by a subtle `1px` border of `#273756`. Used for primary cards, metric groupings, and lists.
- **Level 3 (Interactive Controls & Badges):** High-elevation surface `#2D3D5E` with dynamic pseudo-state shifts.
- **Status Luminescence:** When a critical threshold or diagnostic pulse occurs (e.g., thermal limit reached), the elevated card does not shift upwards physically; instead, it emits an ambient, diffused inner glow or outline tint utilizing the respective semantic color (`#FF8A8A` or `#8FE3C0`) at 15–20% opacity with a 12px blur radius.
- **Glass Overlays:** Modal sheets and sticky app-bar elements apply `background: rgba(21, 30, 50, 0.85)` with a `16px` backdrop-filter blur.

## Shapes

The interface embraces the rounded, human-centric geometry of modern Material 3, establishing consistent spatial boundaries:

- **Standard Cards:** Fixed corner radius of `20px` (`1.25rem`), providing the characteristic rounded card silhouette.
- **Nested Gauges & Inner Tiers:** Rounded to `12px` (`0.75rem`) to maintain proportional concentricity within parent containers.
- **Chips, Badges, Status Dots, & Primary Buttons:** Fully pill-shaped (`9999px`) to distinguish actionable controls and states from informational structural cards.
- **Bottom Navigation Floating Pill:** The active destination indicator inside the bottom navigation bar uses an elongated pill form (`32px` height, `64px` width, `9999px` radius).

## Components

### 1. Cards
- **Architecture:** Built with surface `#202C45`, `20px` border radius, and a crisp `1px` outline of `#273756`.
- **Spacing:** `20px` internal padding throughout.
- **Variants:** Standard Metric Card (header, primary numeric readout, sparkline/gauge), Actionable Process Card (service title, PID/memory badge, kill switch).

### 2. Buttons
- **Primary:** Background `#9CC7FF`, label `#0A1020` in `label-lg`, fully rounded pill (`9999px`). State changes invoke a 10% brightness increase; pressed states apply a subtle scale down to `0.98`.
- **Tonal / Diagnostic:** Background `#2D3D5E`, label `#F4F7FC`, bordered with `1px` `#3D517A`.
- **Destructive:** Background `rgba(255, 138, 138, 0.15)`, text `#FF8A8A`, bordered with `1px` `rgba(255, 138, 138, 0.4)`.

### 3. Metric Badges & Status Dots
- **Pill Badges:** Height `24px`, padding `0 10px`, radius `9999px`. Composed of a faint semantic tinted background (12% opacity) paired with high-contrast text (`label-sm`).
- **Live Status Dots:** `8px` circle with a `2px` concentric aura at 30% opacity. Pulsing animations are restricted to active background processes or anomaly detections.

### 4. Gauge Pills & Progress Tracks
- **Track Base:** Height `8px` or `12px`, background `#151E32`, fully rounded.
- **Indicator Fill:** High-contrast rounded stroke using semantic tokens (`#8FE3C0` for normal, shifting to `#FFD18A` at 75%, and `#FF8A8A` at 90%+). Smooth cubic-bezier transitions (`ease-out`, 300ms) on metric updates.

### 5. Input Fields & Search Bars
- **Container:** Height `52px`, background `#151E32`, radius `16px`, border `1px solid #273756`.
- **Focus State:** Border color switches to `#9CC7FF` with a subtle `0 0 0 3px rgba(156, 199, 255, 0.2)` glow ring. Typography utilizes `body-md` in `#F4F7FC`.

### 6. Five-Item Bottom Navigation Bar
- **Container:** Fixed bottom dock, height `80px`, background `rgba(21, 30, 50, 0.95)` with `20px` blur, bordered along the top edge with `1px solid #273756`.
- **Items:** Five equidistant nodes:
  1. **Home** (Telemetry Dashboard)
  2. **Health** (Battery, Thermals & Degradation)
  3. **App Usage** (Resource Profiler & CPU load)
  4. **History** (Benchmark logs & crash analytics)
  5. **Settings** (Booster triggers & kernel thresholds)
- **Active State Indicator:** An expressive horizontal pill (`64px × 32px`) in `#2D3D5E` behind the active icon, with the active icon and label rendered in `#9CC7FF`. Inactive items are rendered in `#ABB7CC` with no pill background.

### 7. Form Controls (Switches, Radios, Checkboxes)
- **Material Switches:** Track width `52px`, height `32px`, pill-shaped. Inactive track `#151E32` with `#ABB7CC` thumb. Active track `#9CC7FF` with thumb scaled slightly and colored `#0A1020`.